<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ProductController extends Controller
{
public function store(Request $request)
{
    $validated = $request->validate([
        'name'           => 'required|string|max:255',
        'description'    => 'nullable|string',
        'type'           => 'required|in:physical,digital',
        'price'          => 'required|numeric|min:0',
        'stock_quantity' => 'required|integer|min:0',
        'image'          => 'nullable|image|mimes:jpg,jpeg,png|max:2048', // ✅ image validation
    ]);

    if ($request->hasFile('image')) {
        // Save in storage/app/public/products
        $path = $request->file('image')->store('products', 'public');
        $validated['image'] = $path;
    }

    $product = Product::create($validated);

    return response()->json([
        'message' => 'Product created successfully',
        'data'    => [
            'id'            => $product->id,
            'name'          => $product->name,
            'description'   => $product->description,
            'type'          => $product->type,
            'price'         => $product->price,
            'stock_quantity'=> $product->stock_quantity,
            'image'         => $product->image ? asset('storage/' . $product->image) : null, // ✅ full URL
        ],
        'buy_link' => url('/api/products/' . $product->id . '/buy') 
    ], 201);
}


// helper for full image URLs
private function formatProduct($product)
{
    return [
        'id'            => $product->id,
        'name'          => $product->name,
        'description'   => $product->description,
        'type'          => $product->type,
        'price'         => $product->price,
        'stock_quantity'=> $product->stock_quantity,
        'image'         => $product->image ? asset('storage/' . $product->image) : null,
        'created_at'    => $product->created_at,
        'updated_at'    => $product->updated_at,
    ];
}

        // Get all products
public function index()
{
    $products = Product::all()->map(fn($p) => $this->formatProduct($p));
    return response()->json($products);
}

    // Get a single product by ID
public function show($id)
{
    $product = Product::findOrFail($id);
    return response()->json($this->formatProduct($product));
}

    public function buy($id)
{
    $product = Product::findOrFail($id);

    // For now, just return a dummy payment link
    return response()->json([
        'message' => 'Proceed to purchase',
        'product' => $product,
        'payment_link' => 'https://paystack.com/pay/dummy-' . $product->id
    ]);
}
}
